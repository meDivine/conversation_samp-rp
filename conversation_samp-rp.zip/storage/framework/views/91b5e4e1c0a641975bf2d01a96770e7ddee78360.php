<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/error.css')); ?>">
</head>

<body>
<div id="error">
    <div class="error-page container">
        <div class="col-md-8 col-12 offset-md-2">
            <img class="img-error" src="<?php echo e(asset('assets/img/404.png')); ?>" alt="Not Found">
            <div class="text-center">
                <h1 class="error-title">NOT FOUND</h1>
                <p class='fs-5 text-gray-600'>Страница не найдена</p>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-lg btn-outline-primary mt-3">На главную</a>
            </div>
        </div>
    </div>
</div>
</body>

</html>
<?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/errors/404.blade.php ENDPATH**/ ?>