<form wire:submit.prevent="addVote" xmlns:wire="http://www.w3.org/1999/xhtml">
    <div class="form-group">
        <label for="disabledInput">Голос</label>
        <p>
            <li class="d-inline-block me-2 mb-1">
                <div class="form-check">
                    <div class="custom-control custom-checkbox" wire:click="disagreeUpdate">
                        <input type="checkbox"
                               class="form-check-input form-check-danger"
                               name="customCheck" id="customColorCheck4"
                               wire:model="disagree" >
                        <label class="form-check-label"
                               for="customColorCheck4">Отрицательный</label>
                    </div>
                </div>
            </li>
        </p>
        <p>
            <li class="d-inline-block me-2 mb-1" >
                <div class="form-check">
                    <div class="custom-control custom-checkbox" wire:click="neutralUpdate">
                        <input type="checkbox" class="form-check-input form-check-info"
                               name="customCheck" id="customColorCheck5"
                               wire:model="neutral">
                        <label class="form-check-label"
                               for="customColorCheck5" >Нейтральный</label>
                    </div>
                </div>
            </li>
        </p>
        <p>
            <li class="d-inline-block me-2 mb-1">
                <div class="form-check">
                    <div class="custom-control custom-checkbox" wire:click="agreeUpdate">
                        <input type="checkbox"
                               class="form-check-input form-check-success"
                               name="customCheck" id="customColorCheck3"
                               wire:model="agree">
                        <label class="form-check-label"
                               for="customColorCheck3" >Положительный</label>
                    </div>
                </div>
            </li>
        </p>
    </div>

    <div class="col-md-4">
        <label>Комментарий</label>
    </div>
    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="col-md-8 form-group">
        <input type="text" id="first-name" class="form-control"
               name="fname" wire:model="comment" placeholder="Видно тебе и ГА">
    </div>
    <button type="submit" class="btn btn-primary me-1 mb-1">Отправить</button>
</form>
<?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/livewire/admin/conv/vote-form.blade.php ENDPATH**/ ?>