
<?php $__env->startSection('title'); ?>
    <title>Выдвижение администратора</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('conversation.addadmin.editor')->html();
} elseif ($_instance->childHasBeenRendered('QLrp5gQ')) {
    $componentId = $_instance->getRenderedChildComponentId('QLrp5gQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('QLrp5gQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QLrp5gQ');
} else {
    $response = \Livewire\Livewire::mount('conversation.addadmin.editor');
    $html = $response->html();
    $_instance->logRenderedChild('QLrp5gQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/addadmin.blade.php ENDPATH**/ ?>