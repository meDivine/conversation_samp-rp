<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2021 &copy; by butchers</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/base-components/footer.blade.php ENDPATH**/ ?>