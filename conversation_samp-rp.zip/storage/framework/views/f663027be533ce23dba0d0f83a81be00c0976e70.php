<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('components.get.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/chat.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <title>Администратор</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e($convinfo->nickname); ?></h5>
                    <img src="https://flagcdn.com/w20/<?php echo e(strtolower($stats['countryCode'] ?? null)); ?>.webp"
                         alt=""/> <?php echo e($stats['country'] ?? null); ?>,
                    <?php echo e($stats['regionName'] ?? null); ?>, <?php echo e($stats['city'] ?? null); ?> [<a href="#" data-bs-toggle="tooltip"
                                                                                       title="<?php echo e($stats['isp'] ?? null); ?>">?</a>]
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home"
                               role="tab" aria-controls="home" aria-selected="true">Информация</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#reportlog"
                               role="tab" aria-controls="profile" aria-selected="false">Репорт лог</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="suplog-tab" data-bs-toggle="tab" href="#suplog"
                               role="tab" aria-controls="suplog" aria-selected="false">Саппорт лог</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="warns-tab" data-bs-toggle="tab" href="#warns"
                               role="tab" aria-controls="warns" aria-selected="false">Варны</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="kicks-tab" data-bs-toggle="tab" href="#kicks"
                               role="tab" aria-controls="kicks" aria-selected="false">Кики</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="bans-tab" data-bs-toggle="tab" href="#bans"
                               role="tab" aria-controls="bans" aria-selected="false">Баны</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel"
                             aria-labelledby="home-tab">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="disabledInput">Игровой ник</label>
                                            <p class="form-control-static"
                                               id="staticInput"><?php echo e($convinfo->nickname); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="disabledInput">Лидерства</label>
                                            <p class="form-control-static"
                                               id="staticInput"><?php echo e($convinfo->leaderships); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="disabledInput">Ссылка на соц. сеть</label>
                                            <p class="form-control-static" href="<?php echo e($convinfo->social); ?>"
                                               id="staticInput"><?php echo e($convinfo->social); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="disabledInput">О кандидате</label>
                                            <p class="form-control-static" id="staticInput"><?php echo e($convinfo->about); ?></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="disabledInput">Реальное имя</label>
                                            <p class="form-control-static"
                                               id="staticInput"><?php echo e($convinfo->real_name); ?></p>
                                        </div>
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.conv.vote-form', ['convId' => $convinfo->id,'conv_id' => $convinfo->id])->html();
} elseif ($_instance->childHasBeenRendered('5NjyBK7')) {
    $componentId = $_instance->getRenderedChildComponentId('5NjyBK7');
    $componentTag = $_instance->getRenderedChildComponentTagName('5NjyBK7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5NjyBK7');
} else {
    $response = \Livewire\Livewire::mount('admin.conv.vote-form', ['convId' => $convinfo->id,'conv_id' => $convinfo->id]);
    $html = $response->html();
    $_instance->logRenderedChild('5NjyBK7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="reportlog" role="tabpanel"
                             style="height:500px; background: #fff; border: 1px solid #C1C1C1; overflow: auto; "
                             aria-labelledby="reportlog-tab">
                            <?php $__currentLoopData = $replogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-2"><?php echo e($replog ?? null); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade" id="suplog" role="tabpanel"
                             style="height:500px; background: #fff; border: 1px solid #C1C1C1; overflow: auto; "
                             aria-labelledby="suplog-tab">
                            <?php $__currentLoopData = $suplogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suplog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-2"><?php echo e($suplog ?? null); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade"
                             style="height:500px; background: #fff; border: 1px solid #C1C1C1; overflow: auto; "
                             id="warns" role="tabpanel"
                             aria-labelledby="warns-tab">
                            <?php $__currentLoopData = $warns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-2"><?php echo e($warn ?? null); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade"
                             style="height:500px; background: #fff; border: 1px solid #C1C1C1; overflow: auto; "
                             id="kicks" role="tabpanel"
                             aria-labelledby="kicks-tab">
                            <?php $__currentLoopData = $kicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-2"><?php echo e($kick ?? null); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade"
                             style="height:500px; background: #fff; border: 1px solid #C1C1C1; overflow: auto; "
                             id="bans" role="tabpanel"
                             aria-labelledby="bans-tab">
                            <?php $__currentLoopData = $bans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mt-2"><?php echo e($ban ?? null); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('conversation.chat', ['convId' => $convinfo->id,'conv_id' => $convinfo->id])->html();
} elseif ($_instance->childHasBeenRendered('TSgQ6Qk')) {
    $componentId = $_instance->getRenderedChildComponentId('TSgQ6Qk');
    $componentTag = $_instance->getRenderedChildComponentTagName('TSgQ6Qk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TSgQ6Qk');
} else {
    $response = \Livewire\Livewire::mount('conversation.chat', ['convId' => $convinfo->id,'conv_id' => $convinfo->id]);
    $html = $response->html();
    $_instance->logRenderedChild('TSgQ6Qk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <script>
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/components/get/admin/admininfo.blade.php ENDPATH**/ ?>