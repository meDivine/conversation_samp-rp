<div class="col-md-6" xmlns:wire="http://www.w3.org/1999/xhtml">
    <div class="card">
        <div class="card-header">
            <div class="media d-flex align-items-center">
                <div class="avatar me-3">
                    <img src="<?php echo e(Auth::user()->avatar); ?>" alt="" srcset="">
                    <span class="avatar-status bg-success"></span>
                </div>
                <div class="name flex-grow-1">
                    <h6 class="mb-0">Обсуждение</h6>
                    <span class="text-xs"><?php echo e(Auth::user()->nickname); ?></span>
                </div>
                <button class="btn btn-sm">
                    <i data-feather="x"></i>
                </button>
            </div>
        </div>
        <div class="card-body pt-4 bg-grey" style="overflow: auto;height: 400px; ">
            <div class="chat-content">
                <div class="chat chat-left">
                    <div class="chat-body" wire:init="renderChatMessages">
                        <div wire:loading="renderChatMessages">
                            <div style="text-align: center;">
                                <img src="<?php echo e(asset('assets/img/ObviousSoupyArthropods-size_restricted.gif')); ?>" height="320px" width="320px">
                            </div>
                        </div>
                        <?php $__currentLoopData = $chatMess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="chat-message">
                                <div class="avatar me-3">
                                    <img src="<?php echo e($key->userInfo->avatar); ?>" alt="" srcset="">
                                </div>

                                <span style="color: #eeff0f"><?php echo e($key->created_at->format('H:i d.m.y')); ?> <?php echo e($key->userInfo->nickname); ?> (<?php echo e($key->userInfo->name); ?>)</span>
                                <br>
                                <?php echo e($key->message); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <form wire:submit.prevent="send">
            <div class="message-form d-flex flex-direction-column align-items-center">
                <a href="http://" class="black"><i data-feather="smile"></i></a>
                <div class="d-flex flex-grow-1 ml-4">
                    <input type="text" wire:model="mess" class="form-control" placeholder="Максимум 1024 символа">
                </div>
                <?php $__errorArgs = ['mess'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Отправить</button>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/livewire/conversation/chat.blade.php ENDPATH**/ ?>