
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('components.homepage.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <title>Тест тайтл</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.conv.tableconv')->html();
} elseif ($_instance->childHasBeenRendered('lCPgwxg')) {
    $componentId = $_instance->getRenderedChildComponentId('lCPgwxg');
    $componentTag = $_instance->getRenderedChildComponentTagName('lCPgwxg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lCPgwxg');
} else {
    $response = \Livewire\Livewire::mount('admin.conv.tableconv');
    $html = $response->html();
    $_instance->logRenderedChild('lCPgwxg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexa\PhpstormProjects\conversation_samp-rp\resources\views/components/homepage/home.blade.php ENDPATH**/ ?>