<?php

namespace Tests\Unit;

use App\Models\CaptureLog;
use App\Notifications\Vkontakte;
use Illuminate\Support\Facades\Notification;
use PHPUnit\Framework\TestCase;

class VkontakteNotificationTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return \Illuminate\Http\Client\Response
     */
    public function test_example()
    {
       /* $vk = new CaptureLog();
        $vk->sendVkMess(165685444, "test\ntest");*/
    }
    public function TestVkNotify() {

    }
}
