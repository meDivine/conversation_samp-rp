<?php return array (
  'admin.conv.tableconv' => 'App\\Http\\Livewire\\Admin\\Conv\\Tableconv',
  'admin.conv.vote-form' => 'App\\Http\\Livewire\\Admin\\Conv\\VoteForm',
  'conversation.addadmin.editor' => 'App\\Http\\Livewire\\Conversation\\Addadmin\\Editor',
  'conversation.addmessage' => 'App\\Http\\Livewire\\Conversation\\Addmessage',
  'conversation.chat' => 'App\\Http\\Livewire\\Conversation\\Chat',
);