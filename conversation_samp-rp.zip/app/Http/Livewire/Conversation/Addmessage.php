<?php

namespace App\Http\Livewire\Conversation;

use Livewire\Component;

class Addmessage extends Component
{
    public function render()
    {
        return view('livewire.conversation.addmessage');
    }
}
