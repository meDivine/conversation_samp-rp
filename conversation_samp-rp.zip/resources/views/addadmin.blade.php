@extends('base')
@section('title')
    <title>Выдвижение администратора</title>
@endsection
@section('content')
    @livewire('conversation.addadmin.editor')
@endsection
