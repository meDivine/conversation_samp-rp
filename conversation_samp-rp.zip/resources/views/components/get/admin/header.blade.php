<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3>Выдвижение администратора</h3>
            <p class="text-subtitle text-muted">Мб что то будет тут</p>
        </div>
    </div>
</div>
